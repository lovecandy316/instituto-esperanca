import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import emblema from "@/assets/emblema.webp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Instituto Esperança — Reconstruindo vidas" },
      {
        name: "description",
        content:
          "Organização sem fins lucrativos que oferece auxílio humanitário a comunidades afetadas por desastres naturais e situações de crise.",
      },
      { property: "og:title", content: "Instituto Esperança" },
      {
        property: "og:description",
        content:
          "Apoio emergencial, doações e voluntariado para famílias afetadas por desastres e crises.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

function Index() {
  return (
    <SiteLayout
      titulo="Instituto Esperança"
      subtitulo="Reconstruindo vidas, transformando futuros."
      emblema={
        <img
          src={emblema}
          alt="Emblema do Instituto Esperança"
          className="h-20 w-20 object-contain"
        />
      }
    >
      <section className="ie-section col-span-12 sm:col-span-12 md:col-span-7 lg:col-span-7 xl:col-span-8">
        <h2 className="text-3xl font-bold">Quem somos</h2>
        <p className="mt-4">
          O Instituto Esperança é uma organização sem fins lucrativos dedicada a
          oferecer auxílio humanitário a pessoas e comunidades afetadas por
          desastres naturais e situações de crise.
        </p>
        <p className="mt-4">
          Atuamos na prestação de apoio emergencial, arrecadação de recursos e
          mobilização de voluntários, contribuindo para que famílias afetadas
          possam reconstruir suas vidas e seus futuros.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="ie-badge">Ação social</span>
          <span className="ie-badge">Apoio humanitário</span>
          <span className="ie-badge">Voluntariado</span>
        </div>
      </section>

      <section className="ie-section col-span-12 sm:col-span-10 sm:col-start-2 md:col-span-5 md:col-start-auto lg:col-span-5 xl:col-span-4">
        <h2 className="text-3xl font-bold">Entre em contato</h2>
        <p className="mt-4">Endereço: Rua da Esperança, 100 - Centro</p>
        <p>Telefone: (48) 99999-0000</p>
        <p>E-mail: contato@institutoesperanca.org</p>
      </section>

      <div className="ie-alerta col-span-12">
        <strong>Informação:</strong> Conheça nossos projetos sociais e veja como
        você pode ajudar.
      </div>
    </SiteLayout>
  );
}
