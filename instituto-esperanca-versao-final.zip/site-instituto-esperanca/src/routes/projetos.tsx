import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/projetos")({
  head: () => ({
    meta: [
      { title: "Projetos Sociais — Instituto Esperança" },
      {
        name: "description",
        content:
          "Conheça as ações de doações e voluntariado do Instituto Esperança e saiba como participar.",
      },
      { property: "og:title", content: "Projetos Sociais — Instituto Esperança" },
      {
        property: "og:description",
        content:
          "Doações e voluntariado: veja como apoiar as famílias atendidas pelo Instituto Esperança.",
      },
      { property: "og:type", content: "article" },
      { property: "og:url", content: "/projetos" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/projetos" }],
  }),
  component: Projetos,
});

function Toast({ texto }: { texto: string }) {
  return (
    <div className="fixed bottom-6 right-6 z-20 rounded-lg bg-primary px-6 py-4 text-primary-foreground shadow-lg">
      {texto}
    </div>
  );
}

function Modal({
  titulo,
  texto,
  onConfirmar,
  onFechar,
}: {
  titulo: string;
  texto: string;
  onConfirmar: () => void;
  onFechar: () => void;
}) {
  return (
    <div className="ie-modal" role="dialog" aria-modal="true" onClick={onFechar}>
      <div className="ie-modal-caixa" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-2xl font-bold text-primary">{titulo}</h3>
        <p className="mt-4">{texto}</p>
        <div className="mt-6 flex justify-end gap-3">
          <button
            type="button"
            className="ie-botao"
            onClick={onConfirmar}
          >
            Confirmar
          </button>
          <button
            type="button"
            className="rounded-md border border-border bg-card px-6 py-2 font-medium text-foreground transition-colors hover:bg-muted"
            onClick={onFechar}
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
}

function Projetos() {
  const [toast, setToast] = useState<string | null>(null);
  const [modal, setModal] = useState<"doacoes" | "voluntariado" | null>(null);

  const mostrar = (texto: string) => {
    setToast(texto);
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <SiteLayout
      titulo="Projetos Sociais"
      subtitulo="Conheça nossas ações e saiba como participar."
    >
      <div className="ie-alerta col-span-12">
        <strong>Importante:</strong> Sua participação ajuda a ampliar o
        atendimento às comunidades afetadas.
      </div>

      <section
        id="doacoes"
        className="ie-section col-span-12 sm:col-span-12 md:col-span-6 lg:col-span-7 xl:col-span-7 scroll-mt-8"
      >
        <h2 className="text-3xl font-bold">Doações</h2>
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="ie-badge">Doações</span>
          <span className="ie-badge">Apoio emergencial</span>
        </div>
        <p className="mt-4">
          As doações ajudam o Instituto Esperança a oferecer apoio humanitário
          às pessoas e comunidades afetadas por desastres naturais e situações
          de crise.
        </p>
        <p className="mt-4">
          Os recursos arrecadados são utilizados para adquirir e distribuir
          alimentos, água, roupas, materiais de higiene e outros itens
          necessários para as famílias atendidas.
        </p>
        <h3 className="mt-6 text-2xl font-semibold">Como as doações ajudam</h3>
        <p className="mt-2">
          As contribuições permitem ampliar as ações emergenciais, atender mais
          famílias e apoiar a reconstrução das comunidades afetadas.
        </p>
        <button
          type="button"
          className="ie-botao mt-6"
          onClick={() => setModal("doacoes")}
        >
          Quero ajudar
        </button>
      </section>

      <section
        id="voluntariado"
        className="ie-section col-span-12 sm:col-span-12 md:col-span-6 lg:col-span-5 xl:col-span-5 scroll-mt-8"
      >
        <h2 className="text-3xl font-bold">Voluntariado</h2>
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="ie-badge">Voluntariado</span>
          <span className="ie-badge">Ação social</span>
        </div>
        <p className="mt-4">
          O trabalho voluntário permite contribuir diretamente com as ações do
          Instituto Esperança e ajudar pessoas que enfrentam situações de
          emergência.
        </p>
        <p className="mt-4">
          Os voluntários podem participar de atividades de arrecadação,
          organização e distribuição de donativos, além de outras ações
          realizadas pela organização.
        </p>
        <h3 className="mt-6 text-2xl font-semibold">Como participar</h3>
        <p className="mt-2">
          Para participar como voluntário, o interessado deve entrar em contato
          com o Instituto Esperança e informar seu interesse em colaborar com as
          ações sociais.
        </p>
        <button
          type="button"
          className="ie-botao mt-6"
          onClick={() => setModal("voluntariado")}
        >
          Fazer cadastro
        </button>
      </section>

      {modal && (
        <Modal
          titulo={modal === "doacoes" ? "Quero ajudar com doações" : "Quero ser voluntário"}
          texto={
            modal === "doacoes"
              ? "Confirme seu interesse em ajudar com doações. Registramos seu contato para que o Instituto Esperança possa retornar com mais informações."
              : "Confirme seu interesse em participar como voluntário. Registramos seu contato para que o Instituto Esperança possa retornar com mais informações."
          }
          onConfirmar={() => {
            mostrar(
              modal === "doacoes"
                ? "Sucesso! Interesse em ajudar registrado."
                : "Sucesso! Interesse em participar registrado."
            );
            setModal(null);
          }}
          onFechar={() => setModal(null)}
        />
      )}

      {toast && <Toast texto={toast} />}
    </SiteLayout>
  );
}
