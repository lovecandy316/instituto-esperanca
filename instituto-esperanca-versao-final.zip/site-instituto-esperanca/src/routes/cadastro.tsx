import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/cadastro")({
  head: () => ({
    meta: [
      { title: "Cadastro — Instituto Esperança" },
      {
        name: "description",
        content:
          "Cadastre-se para participar das ações de doação e voluntariado do Instituto Esperança.",
      },
      { property: "og:title", content: "Cadastro — Instituto Esperança" },
      {
        property: "og:description",
        content:
          "Preencha seus dados e participe das ações sociais do Instituto Esperança.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/cadastro" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/cadastro" }],
  }),
  component: Cadastro,
});

const campoLabel = "font-medium";

function Cadastro() {
  const [enviado, setEnviado] = useState(false);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setEnviado(true);
    setTimeout(() => setEnviado(false), 3000);
  };

  return (
    <SiteLayout
      titulo="Cadastro"
      subtitulo="Cadastre-se para participar das ações do Instituto Esperança."
    >
      <section className="ie-section col-span-12 sm:col-span-12 md:col-span-10 lg:col-span-8 xl:col-span-8">
        <h2 className="text-3xl font-bold">Formulário de cadastro</h2>

        <form onSubmit={onSubmit} className="mt-6 flex flex-col gap-6">
          <fieldset className="ie-fieldset">
            <legend className="ie-legend">Dados pessoais</legend>

            <label htmlFor="nome" className={campoLabel}>
              Nome completo:
            </label>
            <input id="nome" name="nome" type="text" required className="ie-input" />

            <label htmlFor="cpf" className={campoLabel}>
              CPF:
            </label>
            <input
              id="cpf"
              name="cpf"
              type="text"
              pattern="[0-9]{3}\.[0-9]{3}\.[0-9]{3}-[0-9]{2}"
              placeholder="000.000.000-00"
              required
              className="ie-input"
            />

            <label htmlFor="nascimento" className={campoLabel}>
              Data de nascimento:
            </label>
            <input
              id="nascimento"
              name="nascimento"
              type="date"
              required
              className="ie-input"
            />
          </fieldset>

          <fieldset className="ie-fieldset">
            <legend className="ie-legend">Contato</legend>

            <label htmlFor="email" className={campoLabel}>
              E-mail:
            </label>
            <input id="email" name="email" type="email" required className="ie-input" />

            <label htmlFor="telefone" className={campoLabel}>
              Telefone:
            </label>
            <input
              id="telefone"
              name="telefone"
              type="tel"
              placeholder="(00) 00000-0000"
              required
              className="ie-input"
            />
          </fieldset>

          <fieldset className="ie-fieldset">
            <legend className="ie-legend">Endereço</legend>

            <label htmlFor="cep" className={campoLabel}>
              CEP:
            </label>
            <input
              id="cep"
              name="cep"
              type="text"
              pattern="[0-9]{5}-[0-9]{3}"
              placeholder="00000-000"
              required
              className="ie-input"
            />

            <label htmlFor="endereco" className={campoLabel}>
              Endereço:
            </label>
            <input id="endereco" name="endereco" type="text" required className="ie-input" />

            <label htmlFor="cidade" className={campoLabel}>
              Cidade:
            </label>
            <input id="cidade" name="cidade" type="text" required className="ie-input" />

            <label htmlFor="estado" className={campoLabel}>
              Estado:
            </label>
            <input id="estado" name="estado" type="text" required className="ie-input" />
          </fieldset>

          <button type="submit" className="ie-botao self-start">
            Enviar cadastro
          </button>
        </form>
      </section>

      {enviado && (
        <div className="fixed bottom-6 right-6 z-20 rounded-lg bg-primary px-6 py-4 text-primary-foreground shadow-lg">
          Cadastro enviado com sucesso.
        </div>
      )}
    </SiteLayout>
  );
}
