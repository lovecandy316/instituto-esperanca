import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import bannerAsset from "@/assets/banner-instituto.jpg.asset.json";

function Nav() {
  const [aberto, setAberto] = useState(false);
  const [escuro, setEscuro] = useState(false);

  useEffect(() => {
    const preferencia = localStorage.getItem("tema") === "escuro";
    setEscuro(preferencia);
    document.body.classList.toggle("dark", preferencia);
  }, []);

  function alternarTema() {
    const novoTema = !escuro;
    setEscuro(novoTema);
    document.body.classList.toggle("dark", novoTema);
    localStorage.setItem("tema", novoTema ? "escuro" : "claro");
  }

  const linkClass =
    "text-primary transition-colors hover:text-secondary font-medium";

  return (
    <nav className="border-b border-border bg-card px-6 py-4">
      <div className="mx-auto flex max-w-[1200px] flex-col gap-3 md:flex-row md:items-center md:gap-8">
        <button
          type="button"
          onClick={() => setAberto((v) => !v)}
          className="self-start font-bold text-primary md:hidden"
          aria-expanded={aberto}
        >
          ☰ Menu
        </button>

        <div
          className={`${aberto ? "flex" : "hidden"} flex-col items-start gap-4 md:flex md:flex-row md:items-center md:gap-8`}
        >
          <Link to="/" className={linkClass} onClick={() => setAberto(false)}>
            Início
          </Link>

          <div className="group relative">
            <Link
              to="/projetos"
              className={linkClass}
              onClick={() => setAberto(false)}
            >
              Projetos Sociais
            </Link>
            <div className="z-10 mt-2 hidden min-w-[180px] rounded-md border border-border bg-card p-2 shadow-lg group-hover:block md:absolute md:left-0 md:top-full md:mt-0">
              <Link
                to="/projetos"
                hash="doacoes"
                className={`${linkClass} block p-2`}
                onClick={() => setAberto(false)}
              >
                Doações
              </Link>
              <Link
                to="/projetos"
                hash="voluntariado"
                className={`${linkClass} block p-2`}
                onClick={() => setAberto(false)}
              >
                Voluntariado
              </Link>
            </div>
          </div>

          <Link
            to="/cadastro"
            className={linkClass}
            onClick={() => setAberto(false)}
          >
            Cadastro
          </Link>

          <button
            type="button"
            onClick={alternarTema}
            className="rounded-md border border-border px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted focus-visible:outline-2 focus-visible:outline-accent focus-visible:outline-offset-2"
            aria-pressed={escuro}
          >
            {escuro ? "Modo claro" : "Modo escuro"}
          </button>
        </div>
      </div>
    </nav>
  );
}

export function SiteLayout({
  titulo,
  subtitulo,
  emblema,
  children,
}: {
  titulo: string;
  subtitulo: string;
  emblema?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="ie-banner px-6 py-10 text-foreground md:py-14">
        <img
          src={bannerAsset.url}
          alt=""
          aria-hidden="true"
          className="ie-banner-img"
        />
        <div className="ie-banner-veu" />
        <div className="relative mx-auto flex min-h-[220px] max-w-[1200px] flex-col items-center justify-center gap-6 text-center md:flex-row md:justify-between md:text-left">
          {emblema}
          <div>
            <h1 className="text-4xl font-bold text-primary">{titulo}</h1>
            <p className="mt-1 text-muted-foreground">{subtitulo}</p>
          </div>
        </div>
      </header>

      <Nav />

      <main className="mx-auto w-full max-w-[1200px] flex-1 p-6 md:p-12">
        <div className="ie-grid">{children}</div>
      </main>

      <footer className="bg-primary px-6 py-6 text-primary-foreground">
        <div className="mx-auto max-w-[1200px]">
          <p>Instituto Esperança - 2026</p>
        </div>
      </footer>
    </div>
  );
}
